INSERT INTO 'users' (
    'name','email','passord'
)
VALUES (
    'John','john@email.com','1234'
    )

